package model

type Object struct {
	Name        string
	Content     []byte
	ContentType string
}
