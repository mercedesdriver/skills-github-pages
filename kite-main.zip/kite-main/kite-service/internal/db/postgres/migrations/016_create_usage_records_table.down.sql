DROP TABLE IF EXISTS usage_records;
