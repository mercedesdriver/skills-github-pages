ALTER TABLE apps DROP COLUMN IF EXISTS disabled_reason;
