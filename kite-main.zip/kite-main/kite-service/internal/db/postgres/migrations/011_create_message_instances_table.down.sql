DROP TABLE IF EXISTS message_instances;
