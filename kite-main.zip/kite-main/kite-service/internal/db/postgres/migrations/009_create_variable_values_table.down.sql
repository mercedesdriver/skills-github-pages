DROP TABLE IF EXISTS variable_values;
