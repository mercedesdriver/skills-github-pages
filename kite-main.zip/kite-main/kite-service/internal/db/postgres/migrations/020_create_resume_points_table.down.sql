DROP TABLE IF EXISTS resume_points;
