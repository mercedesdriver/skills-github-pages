package wire

type AuthLogoutResponse = Empty
