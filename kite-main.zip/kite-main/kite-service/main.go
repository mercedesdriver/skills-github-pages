package main

import (
	"github.com/kitecloud/kite/kite-service/cmd"
)

func main() {
	cmd.Execute()
}
